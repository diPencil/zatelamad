import { Target } from "lucide-react"

export function Vision() {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Target className="h-16 w-16 text-primary mx-auto mb-8" />
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-8 text-foreground">رؤيتنا المستقبلية</h2>
          <p className="text-lg leading-relaxed text-muted-foreground">
            تسعى شركة ذات العماد إلى التوسع في تنفيذ المشروعات الكبرى، وتطوير أدواتها التنفيذية، مع الحفاظ على قيم
            الجودة، الالتزام، والاحترافية.
          </p>
        </div>
      </div>
    </section>
  )
}
