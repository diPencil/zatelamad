export function About() {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-8 text-foreground">من نحن</h2>
            <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
              <p>
                شركة <span className="text-foreground font-semibold">ذات العماد للمقاولات العامة</span> هي إحدى الشركات
                المصرية التي استطاعت خلال أكثر من عشر سنوات أن ترسخ مكانتها في سوق المقاولات، من خلال تنفيذ مشروعات
                متنوعة تعتمد على التخطيط الدقيق، وضبط الجودة، والالتزام الكامل بمواعيد التسليم.
              </p>
              <div className="grid grid-cols-2 gap-4 pt-6">
                <div className="border-r-2 border-primary pr-4">
                  <div className="text-3xl font-bold text-foreground mb-2">+10</div>
                  <div className="text-sm text-muted-foreground">سنوات خبرة</div>
                </div>
                <div className="border-r-2 border-primary pr-4">
                  <div className="text-3xl font-bold text-foreground mb-2">+50</div>
                  <div className="text-sm text-muted-foreground">مشروع منفذ</div>
                </div>
              </div>
            </div>
          </div>
          <div className="relative h-[400px] lg:h-[600px]">
            <img src="/modern-concrete-building-architecture-construction.jpg" alt="About" className="h-full w-full object-cover rounded-lg" />
          </div>
        </div>
      </div>
    </section>
  )
}
