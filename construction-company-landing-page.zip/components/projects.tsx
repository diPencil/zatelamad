"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const projects = [
  {
    title: "إسكان مميز – جهاز أكتوبر الجديدة",
    description: "تنفيذ عمارات إسكان مميز وفقًا للمواصفات الفنية المعتمدة مع الالتزام بالجودة والجدول الزمني.",
    image: "/modern-residential-apartment-building-construction.jpg",
  },
  {
    title: "الإسكان الاجتماعي – 800 فدان",
    description: "المشاركة في تنفيذ أحد أكبر مشروعات الإسكان الاجتماعي مع تحقيق التوازن بين سرعة التنفيذ وجودة البناء.",
    image: "/large-scale-social-housing-development.jpg",
  },
  {
    title: "مشروعات الخدمات العامة",
    description:
      "تنفيذ مبانٍ خدمية متكاملة (مدارس – وحدات صحية – حضانات – أسواق تجارية) تراعي طبيعة الاستخدام اليومي والاشتراطات الحكومية.",
    image: "/modern-school-building-public-services.jpg",
  },
  {
    title: "غرب المطار – المرحلة السادسة",
    description: "تنفيذ 7 عمارات سكنية مع توحيد جودة التنفيذ والانضباط الزمني.",
    image: "/residential-towers-under-construction.jpg",
  },
  {
    title: "استكمال 12 عمارة – غرب المطار",
    description: "استكمال أعمال إسكان اجتماعي مع الحفاظ على مطابقة المواصفات الأصلية.",
    image: "/apartment-complex-construction-site.jpg",
  },
  {
    title: "مدارس هيئة الأبنية التعليمية",
    description: "تنفيذ مدارس تعليمية وفق الاشتراطات الهندسية والتعليمية.",
    image: "/educational-building-school-construction.jpg",
  },
  {
    title: "إسكان اجتماعي – جهاز حدائق أكتوبر",
    description: "تنفيذ 5 عمارات إسكان اجتماعي مع الالتزام بالجودة وسرعة الإنجاز.",
    image: "/social-housing-project-residential-buildings.jpg",
  },
]

export function Projects() {
  const [selectedProject, setSelectedProject] = useState<(typeof projects)[0] | null>(null)

  return (
    <section className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 text-center text-foreground">سابقـة الأعمال</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="group cursor-pointer" onClick={() => setSelectedProject(project)}>
              <div className="relative overflow-hidden rounded-lg mb-4 aspect-[4/3]">
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors">
                {project.title}
              </h3>
              <p className="text-muted-foreground line-clamp-2">{project.description}</p>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        <DialogContent className="max-w-3xl" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedProject?.title}</DialogTitle>
            <DialogDescription className="text-base leading-relaxed pt-4">
              {selectedProject?.description}
            </DialogDescription>
          </DialogHeader>
          <div className="aspect-video relative overflow-hidden rounded-lg">
            <img
              src={selectedProject?.image || "/placeholder.svg"}
              alt={selectedProject?.title}
              className="h-full w-full object-cover"
            />
          </div>
        </DialogContent>
      </Dialog>
    </section>
  )
}
