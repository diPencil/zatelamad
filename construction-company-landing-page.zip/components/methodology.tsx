import { CheckCircle2 } from "lucide-react"

const methodologies = [
  "ربط الأعمال الهندسية بإدارات المشتريات والتنفيذ",
  "التحكم الكامل في التكاليف",
  "دقة الجداول الزمنية",
  "ضمان الجودة الشاملة",
]

export function Methodology() {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-8 text-center text-foreground">
            منهجية العمل المتكاملة
          </h2>
          <p className="text-lg leading-relaxed text-muted-foreground mb-12 text-center">
            تعتمد ذات العماد على ربط الأعمال الهندسية بإدارات المشتريات والتنفيذ، بما يضمن السيطرة الكاملة على المشروع
            وتقليل الاعتماد على المقاولين من الباطن وتحقيق أعلى كفاءة تشغيلية.
          </p>
          <div className="grid md:grid-cols-2 gap-6">
            {methodologies.map((method, index) => (
              <div key={index} className="flex items-start gap-4">
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <span className="text-lg text-foreground">{method}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
