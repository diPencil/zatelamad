import { Building2, Paintbrush } from "lucide-react"

export function Services() {
  return (
    <section className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 text-center text-foreground">
          خدمات التشييد والتنفيذ
        </h2>
        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Structural Works */}
          <div className="bg-card p-8 rounded-lg border border-border">
            <Building2 className="h-12 w-12 text-primary mb-6" />
            <h3 className="text-2xl font-bold mb-6 text-card-foreground">أولًا: الأعمال الإنشائية</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الهياكل الخرسانية
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الأعمال المعدنية والصلب
              </li>
            </ul>
          </div>

          {/* Finishing Works */}
          <div className="bg-card p-8 rounded-lg border border-border">
            <Paintbrush className="h-12 w-12 text-primary mb-6" />
            <h3 className="text-2xl font-bold mb-6 text-card-foreground">ثانيًا: أعمال التشطيبات</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الأرضيات
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الأسقف المعلقة
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الرخام
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الدهانات
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الأعمال الخشبية
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                الواجهات
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
