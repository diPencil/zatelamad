import { TrendingUp, Clock, DollarSign, ShieldCheck } from "lucide-react"

const experiences = [
  {
    icon: TrendingUp,
    title: "رفع الإنتاجية في مواقع العمل",
  },
  {
    icon: Clock,
    title: "تقليل الفاقد الزمني",
  },
  {
    icon: Clock,
    title: "الالتزام بالبرامج الزمنية",
  },
  {
    icon: DollarSign,
    title: "التحكم في التكاليف",
  },
  {
    icon: ShieldCheck,
    title: "تطبيق معايير السلامة المهنية",
  },
]

export function Experience() {
  return (
    <section className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 text-center text-foreground">
          خبرتنا في السوق المصري
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {experiences.map((exp, index) => (
            <div
              key={index}
              className="bg-card p-8 rounded-lg border border-border hover:border-primary transition-colors"
            >
              <exp.icon className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold text-card-foreground">{exp.title}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
