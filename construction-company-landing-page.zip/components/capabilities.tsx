import { Wrench, HardHat, Eye, Award, Users } from "lucide-react"

const capabilities = [
  {
    icon: HardHat,
    title: "كوادر هندسية متخصصة",
  },
  {
    icon: Users,
    title: "فرق تنفيذ مدربة",
  },
  {
    icon: Wrench,
    title: "معدات حديثة",
  },
  {
    icon: Award,
    title: "تراخيص واعتمادات رسمية",
  },
  {
    icon: Eye,
    title: "أنظمة إشراف ومتابعة هندسية",
  },
]

export function Capabilities() {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 text-center text-foreground">
          الإمكانيات والموارد
        </h2>
        <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-8">
          {capabilities.map((capability, index) => (
            <div key={index} className="text-center">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <capability.icon className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">{capability.title}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
