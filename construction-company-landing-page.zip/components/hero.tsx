import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img src="/modern-construction-site-building-concrete-structu.jpg" alt="Construction background" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/30" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-white text-center">
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6 text-balance">ذات العماد للمقاولات العامة</h1>
        <p className="text-xl md:text-2xl lg:text-3xl mb-8 text-balance text-white/90 font-medium">
          خبرة هندسية تمتد لأكثر من 10 سنوات في سوق المقاولات المصرية
        </p>
        <p className="text-base md:text-lg lg:text-xl mb-12 max-w-3xl mx-auto leading-relaxed text-white/80">
          شركة مصرية متخصصة في تنفيذ المشروعات الإنشائية، تعتمد على الجودة، الالتزام، والإدارة الاحترافية.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg">
            سابقـة الأعمال
            <ArrowLeft className="mr-2 h-5 w-5" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white border-white/30 px-8 py-6 text-lg"
          >
            تواصل معنا
            <ArrowLeft className="mr-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
