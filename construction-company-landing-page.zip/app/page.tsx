import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { Experience } from "@/components/experience"
import { Methodology } from "@/components/methodology"
import { Services } from "@/components/services"
import { Capabilities } from "@/components/capabilities"
import { Projects } from "@/components/projects"
import { Quality } from "@/components/quality"
import { Philosophy } from "@/components/philosophy"
import { Vision } from "@/components/vision"
import { Contact } from "@/components/contact"

export default function Page() {
  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <Hero />
      <About />
      <Experience />
      <Methodology />
      <Services />
      <Capabilities />
      <Projects />
      <Quality />
      <Philosophy />
      <Vision />
      <Contact />
    </div>
  )
}
